
# Typescript module
