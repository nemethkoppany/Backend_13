export declare function sayHelloWorld(world: string): string;
