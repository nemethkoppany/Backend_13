declare const verifyToken: (req: any, res: any, next: any) => any;
export default verifyToken;
