declare const config: any;
export default config;
