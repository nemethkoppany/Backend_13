declare const app: any;
export default app;
