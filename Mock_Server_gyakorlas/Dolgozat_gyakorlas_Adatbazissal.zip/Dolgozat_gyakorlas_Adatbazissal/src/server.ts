import app from "./app"

app.listen(3000,()=>{
    console.log("A szerver fut a 3000-es porton")
})